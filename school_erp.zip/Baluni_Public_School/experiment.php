<!DOCTYPE html>
<html oncontextmenu="return false;">
<head>
  <title>Chat-box</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/navbar_content.css">
  <style type="text/css">
    .your {

    }
    .mine {

    }
    .container_new {
      height:1200px;
      background-color:white;
    }

  </style>
</head>
<body style="background-color:wheat;">
    <nav class="navbar navbar-default nav-color">
      <div id="navbar-11" class="container-fluid prop-x nav-pad">
        <div class="container">
           <div class="navbar-header">
            <a class="" href="#">
              <img alt="Brand" src="images/logo.png" style="height:50px;width:50px" class="responsive image-cir">
            </a>
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#dess">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
          </div>
          <div class="collapse navbar-collapse" id="dess">
            <ul class="nav navbar-nav navbar-right mistake">
              <li><a href="index.html" data-toggle="tooltip" data-placement="bottom" title="Go to Home">HOME</a></li>
              <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="We express ourselves through the work we do.">PORTFOLIO</a></li>
              <li><a href="about.html" data-toggle="tooltip" data-placement="bottom" title="click to know about us">ABOUT US</a></li>
              <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="training information">TRAINING</a></li>
              <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="click here get in touch with us">GET IN TOUCH</a></li>
            </ul>
          </div>
        </div>
      </div><!-- /.container-fluid-->
    </nav>
    <div class="container container_new">
      
    </div>


  <script src="js/jquery-3.4.1.min.js"></script>
  <script src="js/bootstrap.js"></script>
</body>
</html>