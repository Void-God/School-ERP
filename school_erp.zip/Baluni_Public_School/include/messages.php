<!-- $(".something").attr( { title:"Test", alt:"Test2" } ); -->
<?php  
    $message[0] = "USER ALREADY EXISTS!";
    $message[1] = "Select Correct Image";
    $message[2] = "Data Uploaded Successfully!";
    $message[3] = "Data Failed to Upload!";
    $message[4] = "Request Accepted Successfully!";
    $message[5] = "Request Rejected!";
    $message[6] = "Request for Password Change is already done by the User. The Password can be changed from PASSWORD REQUEST!";//YET TO DO 
    $message[7] = "Password and Confirm Password donot match!";
    $message[8] = "Password Changed!";
    $message[9] = "Oops! Some problem has occured. Please try again.";
    $message[10] = "You have already requested for Password Change!";
    $message[11] = 'You are not allowed to Request!!';
    $message[12] = 'Details donot match!';
    $message[13] = 'UserID does not exist!';
    $message[14] = 'Request sent! Admin will respond to your Request soon.';// Yet to do
    $message[15] = 'Request Denied! ';
    $message[16] = 'Password and Confirm Password donot match!';
    $message[17] = "No CLASS is assigned!";
    $message[18] = "Class Created Successfully";
    $message[19] = "Access to this page is restricted. Please conact your Admin!";
    $message[20] = "Attendence Uploaded Successfully!";
    $message[21] = "Failed to Upload. Please Try Again!";
    //change 22 in admin_attenance.php because copied from here
    $message[22] = "No STUDENT is allocated in your Class ";
    $message[23] = "CLASS Deleted Successfully!";
    $message[24] = "Oops! Some problem has occured. Please try again.";
    $message[25] = "CLASS Teacher Updated Successfully!";
    $message[26] = "Oops! Some problem has occured. Please try again.";
    $message[27] = "CLASS Not Found!";
    $message[28] = "SUBJECT added Successfully!";
    $message[29] = "USER Edited Successfully!";
    $message[30] = "Oops! Some problem has occured. Please try again.";

    $message[31] = "File Uploaded Successfully!";
    $message[32] = "Oops! Some problem has occured. Please try again.";
    $message[33] = "File size should not exceed 125Mb.";
    $message[34] = "File not allowed. Only PDF,DOCX,MP4 format is allowed!";
    $message[35] = "No CLASS selected!";


    $message[36] = "MARKS Uploaded Successfully!";
    $message[37] = "Oops! Some problem has occured. Please try again.";



    $message[38] = "One TEACHER can be assigned to One Subject only!!";
    $message[39] = "THE NAME already exists. Try a different NAME!";
    $message[40] = "Data Uploaded Successfully!";
    

    $message[41] = "Session Ended Sucessfully";
    $message[42] = "Problem Occured Please Try Again!";


    $message[43] = "Holiday Decleared Successfully";
    $message[44] = "No Day is Selected";

    $message[45] = "Not Enough Space!";

    $message[46] = "Failed!";
    $message[47] = "Discussion Field Created Successfully";
?>
