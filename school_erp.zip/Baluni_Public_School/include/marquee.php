<div style="background-color:blue">
  <marquee direction="left"><p style="font-family:KrutiDev;font-size:20px;color:white">ॐ अखण्डमण्डलाकारं व्याप्तं येन चराचरम्
तत्पदं दर्शितं येन तस्मै श्रीगुरवे नमः </p></marquee>
</div>
<!-- cywuh laLFkku! -->