<?php
  $con = mysqli_connect("localhost","root","","baluni") or die ("Unable to connect");
  //mysqli_select_db($con,"baluni")
?>